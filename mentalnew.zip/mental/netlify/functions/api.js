const resources = [
  { title: "Managing Anxiety", url: "https://www.childline.org.uk/info-advice/your-feelings/anxiety/" },
  { title: "Bullying Support", url: "https://www.childline.org.uk/info-advice/bullying-abuse-safety/" },
  { title: "Mindfulness Exercises", url: "https://www.childline.org.uk/toolbox/mindfulness/" },
  { title: "Dealing with Stress", url: "https://www.childline.org.uk/info-advice/your-feelings/stress/" },
  { title: "Building Confidence", url: "https://www.childline.org.uk/info-advice/your-feelings/self-esteem/" }
];

const users = [
  { id: "stu-1", username: "student", password: "student123", role: "student", name: "Student User" },
  { id: "csl-1", username: "counselor", password: "counselor123", role: "counselor", name: "Counselor User" },
  { id: "adm-1", username: "admin", password: "admin123", role: "admin", name: "Admin User" }
];

const state = globalThis.__mindbridgeState || {
  sessions: new Map(),
  chatHistory: [],
  feedback: [],
  moods: [],
  analytics: {},
  requestLog: new Map()
};
globalThis.__mindbridgeState = state;

const MAX_MESSAGE_LENGTH = 500;
const MAX_FEEDBACK_LENGTH = 1000;

function securityHeaders() {
  return {
    "Content-Type": "application/json",
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type, Authorization, x-session-token",
    "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
    "X-Content-Type-Options": "nosniff",
    "X-Frame-Options": "DENY",
    "Referrer-Policy": "strict-origin-when-cross-origin",
    "Cache-Control": "no-store"
  };
}

function json(statusCode, body) {
  return {
    statusCode,
    headers: securityHeaders(),
    body: JSON.stringify(body)
  };
}

function increment(eventName) {
  state.analytics[eventName] = (state.analytics[eventName] || 0) + 1;
}

function getPath(event) {
  const p = event.path || "";
  return p.replace(/^.*\/\.netlify\/functions\/api/, "") || "/";
}

function getToken(event) {
  const auth = event.headers?.authorization || event.headers?.Authorization || "";
  if (auth.startsWith("Bearer ")) return auth.slice(7).trim();
  return event.headers?.["x-session-token"];
}

function auth(event) {
  const token = getToken(event);
  if (!token || !state.sessions.has(token)) return null;

  const session = state.sessions.get(token);
  if (session.expiresAt < Date.now()) {
    state.sessions.delete(token);
    return null;
  }

  return { token, session };
}

function parseBody(event) {
  if (!event.body) return {};
  try {
    return JSON.parse(event.body);
  } catch {
    return null;
  }
}

function cleanText(input, maxLength) {
  if (typeof input !== "string") return "";
  return input.replace(/[<>]/g, "").trim().slice(0, maxLength);
}

function getClientIp(event) {
  return event.headers?.["x-forwarded-for"]?.split(",")[0]?.trim() || "unknown";
}

function tooManyRequests(event) {
  const ip = getClientIp(event);
  const now = Date.now();
  const windowMs = 60 * 1000;
  const maxInWindow = 120;

  const stamps = state.requestLog.get(ip) || [];
  const recent = stamps.filter((t) => now - t < windowMs);
  recent.push(now);
  state.requestLog.set(ip, recent);

  return recent.length > maxInWindow;
}

exports.handler = async (event) => {
  if (event.httpMethod === "OPTIONS") return json(200, { ok: true });

  if (tooManyRequests(event)) {
    return json(429, { success: false, message: "Too many requests. Please try again shortly." });
  }

  const path = getPath(event);
  const method = event.httpMethod;
  const body = parseBody(event);

  if (body === null) {
    return json(400, { success: false, message: "Invalid JSON payload" });
  }

  if (method === "GET" && path === "/health") {
    return json(200, { ok: true, service: "MindBridge Netlify API", env: "production" });
  }

  if (method === "POST" && path === "/auth/login") {
    const username = cleanText(body.username, 60);
    const password = cleanText(body.password, 120);
    const user = users.find((u) => u.username === username && u.password === password);

    if (!user) {
      increment("loginFailed");
      return json(401, { success: false, message: "Invalid credentials" });
    }

    const token = `mb_${Math.random().toString(36).slice(2)}${Date.now().toString(36)}`;
    state.sessions.set(token, {
      userId: user.id,
      username: user.username,
      role: user.role,
      name: user.name,
      expiresAt: Date.now() + 1000 * 60 * 60 * 8
    });
    increment("loginSuccess");

    return json(200, {
      success: true,
      token,
      user: { id: user.id, username: user.username, name: user.name, role: user.role }
    });
  }

  if (method === "GET" && path === "/auth/me") {
    const authData = auth(event);
    if (!authData) return json(401, { success: false, message: "Unauthorized" });
    return json(200, { success: true, user: authData.session });
  }

  if (method === "POST" && path === "/auth/logout") {
    const authData = auth(event);
    if (!authData) return json(401, { success: false, message: "Unauthorized" });
    state.sessions.delete(authData.token);
    return json(200, { success: true, message: "Logged out" });
  }

  if (method === "POST" && path === "/chat/start") {
    state.chatHistory.push({ type: "session_start", time: Date.now(), source: "homepage" });
    increment("chatStarted");
    return json(200, { success: true, message: "Chat session started. A counselor will join soon." });
  }

  if (method === "POST" && path === "/chat/send") {
    const user = cleanText(body.user, 40);
    const message = cleanText(body.message, MAX_MESSAGE_LENGTH);
    if (!user || !message) return json(400, { success: false, message: "user and message are required" });

    state.chatHistory.push({ user, message, time: Date.now() });
    increment("chatMessages");
    return json(200, { success: true });
  }

  if (method === "POST" && path === "/chat/clear") {
    state.chatHistory = [];
    increment("chatCleared");
    return json(200, { success: true, message: "Chat history cleared." });
  }

  if (method === "GET" && path === "/chat/history") {
    return json(200, { history: state.chatHistory.slice(-200) });
  }

  if (method === "POST" && path === "/call/request") {
    increment("callRequests");
    return json(200, { success: true, message: "Call request received. A counselor will call you shortly." });
  }

  if (method === "GET" && path === "/resources") {
    return json(200, { resources });
  }

  if (method === "POST" && path === "/feedback") {
    const feedback = cleanText(body.feedback, MAX_FEEDBACK_LENGTH);
    const source = cleanText(body.source || "unknown", 60);
    if (!feedback) return json(400, { success: false, message: "feedback is required" });

    state.feedback.push({ feedback, source, time: Date.now() });
    increment("feedbackSubmitted");
    return json(200, { success: true });
  }

  if (method === "POST" && path === "/mood") {
    const mood = cleanText(body.mood, 30);
    if (!mood) return json(400, { success: false, message: "mood is required" });
    state.moods.push({ mood, time: Date.now() });
    increment("moodLogged");
    return json(200, { success: true });
  }

  if (method === "POST" && path === "/analytics") {
    const eventName = cleanText(body.event, 60);
    if (!eventName) return json(400, { success: false, message: "event is required" });
    increment(eventName);
    return json(200, { success: true });
  }

  if (method === "GET" && path === "/analytics") {
    return json(200, { analytics: state.analytics });
  }

  if (method === "GET" && path === "/admin/analytics") {
    const authData = auth(event);
    if (!authData) return json(401, { success: false, message: "Unauthorized" });
    if (authData.session.role !== "admin") return json(403, { success: false, message: "Forbidden" });

    return json(200, {
      success: true,
      analytics: state.analytics,
      overview: {
        totalFeedback: state.feedback.length,
        totalMoodLogs: state.moods.length,
        totalChatEvents: state.chatHistory.length,
        activeSessions: state.sessions.size
      },
      latestFeedback: state.feedback.slice(-5).reverse(),
      latestMoods: state.moods.slice(-10).reverse()
    });
  }

  return json(404, { success: false, message: "Not found" });
};
